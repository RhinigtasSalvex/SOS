import matplotlib.pyplot as plt

# Plot the fitness of the population
x = [10,100, 1000]
y = [0.078125, 0.328125, 4.296875]
plt.plot(x, y)