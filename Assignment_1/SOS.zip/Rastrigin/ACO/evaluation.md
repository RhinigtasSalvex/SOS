#Experiments:

## Easy 1 variable case
Total running time: 27 seconds
Population size: 10
Number variables: 1
Selection rate: 0.6
Mutation rate: 0.1
Number Generations: 200
Best fitness: -0.3564407609576872
Best individual: [-0.04251252]

Total running time: 25 seconds
Population size: 100
Number variables: 1
Selection rate: 0.6
Mutation rate: 0.1
Number Generations: 200
Best fitness: -0.0
Best individual: [-7.9251227e-10]


## 2 variable case
Total running time: 16 seconds
Population size: 10
Number variables: 2
Selection rate: 0.6
Mutation rate: 0.1
Number Generations: 200
Best fitness: -0.14539046477109352
Best individual: [-0.0116221  -0.02447456]

Total running time: 28 seconds
Population size: 100
Number variables: 2
Selection rate: 0.6
Mutation rate: 0.1
Number Generations: 200
Best fitness: -2.1851056430932658e-07
Best individual: [-4.50311219e-10 -3.31874624e-05]

## 3 variable case
Total running time: 22 seconds
Population size: 10
Number variables: 3
Selection rate: 0.6
Mutation rate: 0.1
Number Generations: 200
Best fitness: -1.288725159643505
Best individual: [-0.03628161  0.98326045  0.00578212]

Total running time: 17 seconds
Population size: 100
Number variables: 3
Selection rate: 0.6
Mutation rate: 0.1
Number Generations: 200
Best fitness: -0.033101284911357
Best individual: [-1.77368858e-05  1.29204758e-02 -3.30535801e-08]

Total running time: 31 seconds
Population size: 100
Number variables: 3
Selection rate: 0.6
Mutation rate: 0.1
Number Generations: 300
Best fitness: -4.181492840871215e-08
Best individual: [-3.07014393e-07 -2.57289916e-09  1.45146433e-05]

## 4 variables
Total running time: 37 seconds
Population size: 10
Number variables: 4
Selection rate: 0.6
Mutation rate: 0.1
Number Generations: 200
Best fitness: -1.1972127187425414
Best individual: [ 3.03291967e-02 -1.00489544e+00  1.90710859e-03  9.91073397e-05]

Total running time: 19 seconds
Population size: 100
Number variables: 4
Selection rate: 0.6
Mutation rate: 0.1
Number Generations: 200
Best fitness: -0.00573195945911209
Best individual: [-4.66594060e-03  1.47730140e-08 -2.97394268e-04 -2.65223400e-03]

Total running time: 13 seconds
Population size: 100
Number variables: 4
Selection rate: 0.6
Mutation rate: 0.1
Number Generations: 300
Best fitness: -4.539066559772209e-05
Best individual: [ 1.53884710e-04 -4.52893013e-04  3.48895997e-07 -3.92211120e-07]